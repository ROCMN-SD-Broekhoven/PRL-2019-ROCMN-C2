<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verloren :(</title>

    <link rel="stylesheet" href="algemeen.css">
    <link rel="stylesheet" href="winlose.css">
</head>

<body>
    <div class="middenvlakcontainer">
        <div class="middenvlak">
            <h2>Helaas!</h2>
            <p5>U heeft helaas geen prijs gewonnen</p5>
            <br>
            <img src="media/verloren.png" alt="verloren" class="plaatje">
            <br>
            <a href="login.html">
                <button type="submit" role="button" tabindex="0">Terug naar Login</button>
            </a>
        </div>
    </div>
</body>

</html>